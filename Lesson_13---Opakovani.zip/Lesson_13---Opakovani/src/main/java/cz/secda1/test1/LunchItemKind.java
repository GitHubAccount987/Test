package cz.secda1.test1;

public enum LunchItemKind {
    SOUP,
    MAIN_DISH,
    DRINK;


    @Override
    public String toString() {
        return super.toString();
    }
}
